# Truck Parts AI Finder — Design

Goal: demonstrate a small but real AI-assisted semantic search tool for truck parts.

The app loads a CSV catalog, generates OpenAI embeddings for each row, generates an embedding
for the user's query, ranks rows by cosine similarity, and prints the top matches.

The project intentionally stays small: CLI only, no database, no authentication, no web server.
Core ranking logic is isolated in `src/search.py` and covered by unit tests without live API calls.

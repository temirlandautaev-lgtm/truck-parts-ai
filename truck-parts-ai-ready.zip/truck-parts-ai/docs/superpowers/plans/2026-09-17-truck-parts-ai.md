# Truck Parts AI Finder Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a small public GitHub-ready AI semantic search project for truck parts.

**Architecture:** CSV catalog + OpenAI embeddings + local cosine-similarity ranking + CLI.

**Tech Stack:** Python 3.10+, OpenAI Python SDK, python-dotenv, pytest.

**Spec:** `docs/superpowers/specs/2026-09-17-truck-parts-ai-design.md`

## Global Constraints

- No database.
- No web server.
- API key must be read from environment, never committed.
- Ranking logic must be testable without live API requests.

---

### Task 1: Core semantic ranking

Create `src/search.py` with `Part`, `cosine_similarity`, and `rank_parts`.
Verify with `tests/test_search.py`.

### Task 2: CLI and OpenAI embeddings

Create `app.py` to load the CSV, request embeddings, and display ranked results.

### Task 3: GitHub-ready documentation

Add sample `catalog.csv`, `.env.example`, `.gitignore`, `requirements.txt`, `README.md`, and MIT license.
